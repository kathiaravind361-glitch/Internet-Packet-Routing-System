import { MinPriorityQueue } from './PriorityQueue.js';

const cloneDistances = (distances) => Object.fromEntries(
  Object.entries(distances).map(([node, distance]) => [node, Number.isFinite(distance) ? distance : Infinity]),
);

const clonePrevious = (previous) => ({ ...previous });

export function reconstructPath(previous, source, destination) {
  if (source === destination) return [source];
  if (!previous[destination]) return [];

  const path = [];
  let current = destination;
  while (current) {
    path.unshift(current);
    if (current === source) return path;
    current = previous[current];
  }
  return [];
}

export function dijkstra(nodes, edges, source, destination) {
  const distances = Object.fromEntries(nodes.map((node) => [node.id, Infinity]));
  const previous = Object.fromEntries(nodes.map((node) => [node.id, null]));
  const visited = new Set();
  const queue = new MinPriorityQueue();
  const steps = [];

  if (!distances[source] && distances[source] !== 0) {
    return { distance: Infinity, path: [], steps: [], distances, previous, visited: [] };
  }

  distances[source] = 0;
  queue.insert(source, 0);
  steps.push({
    phase: 'ready',
    currentNode: null,
    visited: [],
    distances: cloneDistances(distances),
    previous: clonePrevious(previous),
    relaxedEdge: null,
    updatedDistance: null,
    message: `Distances initialized from ${source}`,
  });

  while (!queue.isEmpty()) {
    const entry = queue.extractMin();
    if (!entry || visited.has(entry.item)) continue;

    const currentNode = entry.item;
    visited.add(currentNode);
    steps.push({
      phase: 'select',
      currentNode,
      visited: [...visited],
      distances: cloneDistances(distances),
      previous: clonePrevious(previous),
      relaxedEdge: null,
      updatedDistance: null,
      message: `Selected ${currentNode} with the smallest known distance`,
    });

    if (currentNode === destination) break;

    const neighbors = edges.filter((edge) => edge.from === currentNode);
    for (const edge of neighbors) {
      const candidate = distances[currentNode] + edge.weight;
      const changed = candidate < distances[edge.to];

      if (changed) {
        distances[edge.to] = candidate;
        previous[edge.to] = currentNode;
        queue.insert(edge.to, candidate);
      }

      steps.push({
        phase: 'relax',
        currentNode,
        visited: [...visited],
        distances: cloneDistances(distances),
        previous: clonePrevious(previous),
        relaxedEdge: { from: edge.from, to: edge.to, weight: edge.weight },
        updatedDistance: changed ? candidate : null,
        message: changed
          ? `Relaxed ${edge.from} → ${edge.to}; distance updated to ${candidate}`
          : `Checked ${edge.from} → ${edge.to}; current distance is already optimal`,
      });
    }
  }

  const path = reconstructPath(previous, source, destination);
  steps.push({
    phase: path.length ? 'complete' : 'unreachable',
    currentNode: path.length ? destination : null,
    visited: [...visited],
    distances: cloneDistances(distances),
    previous: clonePrevious(previous),
    relaxedEdge: null,
    updatedDistance: null,
    message: path.length ? `Route reconstructed in ${path.length - 1} hops` : `No route from ${source} to ${destination}`,
  });

  return {
    distance: distances[destination],
    path,
    steps,
    distances,
    previous,
    visited: [...visited],
  };
}

export function enumerateRoutes(nodes, edges, source, destination, limit = 4) {
  const found = [];
  const walk = (current, path, cost) => {
    if (found.length >= limit) return;
    if (current === destination) {
      found.push({ path, cost });
      return;
    }

    for (const edge of edges.filter((candidate) => candidate.from === current)) {
      if (path.includes(edge.to)) continue;
      walk(edge.to, [...path, edge.to], cost + edge.weight);
    }
  };

  walk(source, [source], 0);
  return found.sort((a, b) => a.cost - b.cost);
}
