export default {
  logoUrl: "https://dummyimage.com/64x64/365ce8/ffffff.png&text=B"
};
