# BizDirectory prototype plan

## Product direction

Replace the retired RoutePath Dijkstra lab with **BizDirectory**, a light, editorial-style local business discovery platform for a college-project demonstration. The prototype uses fictional records and localStorage so search, details, authentication simulation, and admin CRUD work immediately without pretending that a backend is connected.

## Design decisions

- **Design movement:** editorial SaaS directory with quiet Swiss-like spacing, soft surfaces, and confident blue-purple accents.
- **Core principles:** make search obvious, keep business information scannable, make the next action clear, and keep admin controls organized.
- **Color philosophy:** white and pale blue-gray surfaces keep the directory trustworthy; deep navy anchors hierarchy; blue signals action; purple gives the product an ownable discovery accent.
- **Layout paradigm:** spacious landing sections lead into dense, useful listing cards; the admin area switches to a focused sidebar workspace.
- **Signature elements:** the B gradient mark, category initials, and small directory metadata labels create a consistent visual language without unnecessary decoration.
- **Interaction philosophy:** filters respond immediately, cards always lead to useful details, and prototype boundaries are stated where production services would be required.
- **Animation:** restrained hover lift and soft shadow transitions only; no distracting loops.
- **Typography:** Manrope for readable UI and display hierarchy; DM Mono for small metadata, labels, and prototype status cues.
- **Brand essence:** a calm, trustworthy place to discover local expertise; clear, useful, welcoming.
- **Brand voice:** direct and human. Example lines: “Find the right place for what’s next.” and “Less searching. More finding.”
- **Wordmark:** a rounded gradient B tile paired with a compact two-line wordmark.
- **Signature color:** discovery purple `#7648d8`, balanced by action blue `#365ce8`.

## Implementation

`src/App.jsx` contains the shared shell, home, Explore, details, Categories, About, Contact, auth, and protected admin workspace views. A small hash-router keeps the prototype dependency-light while exposing the requested page routes. The business model includes the required 12 fictional records and all displayed admin statistics are derived from the current stored records.

Business records are initialized from seed data and persisted under `bizdirectory_businesses` in localStorage. The admin workspace updates the same record set for create, edit, and delete operations. Contact messages, simulated auth, and custom categories use separate localStorage keys. `public/images` contains selected business imagery used by fictional listings; image-less records use a branded initials fallback.

`src/styles.css` owns the light responsive visual system. `public/manus-routes.json` declares all public and admin page patterns. The README documents what works in the prototype and which Express, MongoDB, JWT, bcrypt, and email integrations remain for production.
