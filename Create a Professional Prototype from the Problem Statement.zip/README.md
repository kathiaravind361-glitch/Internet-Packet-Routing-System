# BizDirectory — Digital Business Directory

A polished React/Vite frontend prototype for discovering, searching, and managing local businesses. The data is fictional and designed for a college-project demonstration.

## Run locally

```bash
npm install
npm run dev
```

The app listens on `http://localhost:3000`.

## Included prototype flows

- Home page with prominent search, category browsing, featured businesses, statistics, and CTA
- Explore page with combined search, category/city filters, sorting, grid/list views, and empty states
- Business detail pages with services, address, contact information, call, and website actions
- Categories page with direct links into filtered listings
- About and Contact pages with local prototype message storage
- Login and registration interfaces with validation
- Demo admin access: `admin@bizdirectory.demo` through the **Use demo admin access** button
- Admin dashboard with calculated overview statistics
- Business CRUD workflow backed by `localStorage`
- Category management with protection for categories still used by businesses
- Responsive desktop, tablet, and mobile layouts

## Prototype boundary

The frontend currently uses `localStorage` so all records survive refresh during a demo. MongoDB persistence, Express REST APIs, JWT authentication, bcrypt password hashing, email delivery, and secure server-side role checks are not connected in this sandbox prototype. The UI labels those production boundaries where relevant.

## Project structure

- `src/App.jsx` — public pages, business discovery, details, auth simulation, and admin workspace
- `src/styles.css` — light BizDirectory visual system and responsive layout
- `public/images/` — selected business imagery used by fictional listings
- `public/manus-routes.json` — route manifest for the Webdev preview

## Production handoff

The current data model is ready to move behind a service layer. The next production step would be adding Express routes for businesses, categories, users, auth, and contact messages; connecting Mongoose models to MongoDB Atlas; and replacing the localStorage adapters with authenticated API calls.
